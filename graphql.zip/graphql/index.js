const loginPage = `
  <div class="login-container">
    <h1>Login</h1>
    <form id="login-form">
      <input type="text" id="username" placeholder="Username or Email" required />
      <input type="password" id="password" placeholder="Password" required />
      <button type="submit">Login</button>
    </form>
    <p id="error-message" class="hidden">Invalid credentials. Please try again.</p>
  </div>
`;

document.body.innerHTML = loginPage;


const profileHTML = (userData) => `
<div class="Page-Top">
  <div class="compus">
    <img src="/logo.png" alt="Logo" class="logo">
    <h1>Campus ${userData.campus}</h1>
  </div>
  <button id="logout">Logout</button>
</div>
<div class="profile-container">
  <div class="personal-info">
    <h2>Personal Information</h2>
    <p><strong>Username: </strong>${userData.username}</p>
    <p><strong>First Name: </strong>${userData.firstName}</p>
    <p><strong>Last Name: </strong>${userData.lastName}</p>
    <p><strong>Email: </strong>${userData.email}</p>
    <p><strong>Audit Ratio: </strong>${userData.auditRatio}</p>
    <p><strong>Total Uploads: </strong> ${userData.totalUp}</p>
    <p><strong>Total Downloads: </strong> ${userData.totalDown}</p>
    <p><strong>Your XP: </strong> ${UserData.XP}</p>
  </div>
  <div class="projects-success">
    <h2>Number of projects: ${userData.successrojects}</h2>
    <h2>Projects Name</strong></h2>
      ${userData.finished_projects.map(project =>{
        const path = (project.group.path).split('/').pop();
          return `<p>${path}</p>`
        }).join('')
      }
  </div>
  <div class="current-projects">
      <h2>Current Projects</h2>
      ${userData.current_projects.map(project =>{
        const path = (project.group.path).split('/').pop();
          return `<p>${path}</p>`
        }).join('')
      }
  </div>
  <div id="graph1"></div>
  <div id="graph2"></div>
</div>
`;


let UserData = {
  username: "",
  firstName: "",
  lastName: "",
  email: "",
  campus: "",
  auditRatio: "",
  totalUp: "",
  totalDown: "",
  successrojects: 0,
  current_projects: [],
  finished_projects: [],
  XP : 0,
  Skills: [],
};
let members = [];


// API Endpoints
const BASE_URL = "https://learn.zone01oujda.ma/api";
const SIGNIN_URL = `${BASE_URL}/auth/signin`;
const GRAPHQL_URL = `${BASE_URL}/graphql-engine/v1/graphql`;

// Login Functionality
async function login(username, password) {
  const credentials = btoa(`${username}:${password}`);

  try {
    const response = await fetch(SIGNIN_URL, {
      method: "POST",
      headers: {
        Authorization: `Basic ${credentials}`,
      },
    });

    if (!response.ok) throw new Error("Login failed");

    const jwt = await response.json();
    localStorage.setItem("jwt", jwt);
    renderProfilePage();
  } catch (error) {
    document.getElementById("error-message").classList.remove("hidden");
  }
}

// Event Listener for Login Form
const loginForm = document.getElementById("login-form");
loginForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  login(username, password);
});

// **Step 2: Profile Page Rendering**
async function renderProfilePage() {
  const jwt = localStorage.getItem("jwt");

  if (!jwt) {
    document.body.innerHTML = loginPage;
    return;
  }

  const query = `
       query {
  user {
    id
    login
    firstName
    lastName
    email
    campus
    auditRatio
    totalUp
    totalDown
    finished_projects: groups(
      where: {group: {status: {_eq: finished}, _and: [{path: {_like: "%module%"}}, {path: {_nilike: "%piscine-js%"}}]}}
    ) {
      group {
        path
        members{
          userLogin
        }
      }
    }
    current_projects: groups(where: {group: {status: {_eq: working}}}) {
      group {
        path
        status
        members {
          userLogin
        }
      }
    }
    transactions_aggregate(where: {eventId: {_eq: 41}, type: {_eq: "xp"}}) {
      aggregate {
        sum {
          amount
        }
      }
    }
  }
    sklis: transaction(
      distinct_on: type 
      where: { type: { _like: "skill_%" } }
      order_by: [{ type: asc }, { amount: desc }]
    ) {
      type
      amount
    }
}

`
    ;

  try {
    const response = await fetch(GRAPHQL_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${jwt}`,
      },
      body: JSON.stringify({ query }),
    });

    const result = await response.json();

    if (result.errors) {
      console.error("GraphQL Errors:", result.errors);
      throw new Error("Failed to fetch user data");
    }

    const Data = result.data.user;
    UserData.Skills = result.data.sklis;
    
    Data.forEach(Element => {
      UserData.username = Element.login;
      UserData.firstName = Element.firstName;
      UserData.lastName = Element.lastName;
      UserData.email = Element.email;
      UserData.campus = Element.campus;
      UserData.auditRatio = (parseFloat(Element.auditRatio)).toFixed(1);
      UserData.totalUp = formatSize(parseFloat(Element.totalUp));
      UserData.totalDown = formatSize(parseFloat(Element.totalDown));
      UserData.current_projects = Element.current_projects;
      UserData.successrojects = Element.finished_projects.length;
      UserData.finished_projects = Element.finished_projects;
      UserData.XP = formatSize(parseFloat(Element.transactions_aggregate.aggregate.sum.amount),"XP");
    });
    
    UserData.finished_projects.forEach(project => {
      project.group.members.forEach(member => {
        const userlogin = member.userLogin;
        if (userlogin !== UserData.username) {
          let existingMember = members.find(m => m.userlogin === userlogin);
          if (!existingMember) {
            members.push({ userlogin, times: 1 });
          } else {
            existingMember.times++;
          }
        }
      });
    });
    console.log("skill", UserData.Skills);
    
    
    console.log(members);
    
    document.body.innerHTML = profileHTML(UserData);
    const graph1 = document.getElementById("graph1");
    const graph2 = document.getElementById("graph2");
    SVGCREATE(graph1, "graph1");
    SVGCREATE(graph2, "graph2");
    const svg1 = document.getElementById("svg-graph1");
    const svg2 = document.getElementById("svg-graph2");
    GRAPH(svg1, UserData.Skills);
    GRAPH(svg2, members);
    document.getElementById("logout").addEventListener("click", () => {
      localStorage.removeItem("jwt");
      document.body.innerHTML = loginPage;
    });

  } catch (error) {
    console.error("Failed to render profile page:", error);
  }
}


// Initial Render
if (localStorage.getItem("jwt")) {
  renderProfilePage();
}





// Convert totalUp and totalDown, deciding between B, KB, and MB
function formatSize(sizeInBytes,xp) {
  var result;
  if (sizeInBytes < 1000) {
    result = sizeInBytes + " B";
  } else if (sizeInBytes < 1000 * 1000) {
    if (xp === "XP") {
      result = Math.floor(sizeInBytes / 1000) + " kB";
    }else{
      result = (sizeInBytes / 1000).toFixed(2) + " KB";
    }
  } else {
    if (xp === "XP") {
      result = Math.floor(sizeInBytes / 1000 / 1000) + " MB";
    }else{
      sizeInBytes = (sizeInBytes / 1000 / 1000).toFixed(3);
      result = sizeInBytes.slice(0, 4) + " MB";
    }
  }
  return result;
}

function SVGCREATE(graph,id) {
  const svgString = ` 
    <svg xmlns="http://www.w3.org/2000/svg" id="svg-${id}">
      <!-- Dessin des axes -->
      <line x1="0" y1="0" x2="0" y2="100" stroke="black" stroke-width="3" /> <!-- Axe Y -->
      <line x1="" y1="0" x2="500" y2="0" stroke="black" stroke-width="3" /> <!-- Axe X -->
    </svg>`;
  const parser = new DOMParser();
  const svgDoc = parser.parseFromString(svgString, "image/svg+xml");
  const svgElement = svgDoc.documentElement;
  graph.appendChild(svgElement)
}

function GRAPH(){

}



// function SVGCREATE(DATA) {

//   // Sort the data by 'times' in descending order
//   DATA.sort((a, b) => b.times - a.times);

//   // Create an SVG container
//   var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
//   svg.setAttribute("width", "fit-content");
//   svg.setAttribute("height", "400");
  
//   // Set background color of SVG
//   svg.setAttribute("style", "background-color:rgb(255, 255, 255);");

//   // Set bar properties
//   const barWidth = 20;
//   const spacing = 30;

//   // Loop through the data to create bars
//   DATA.forEach((entry, index) => {
//     var rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
//     rect.setAttribute("x", (index * (barWidth + spacing)) + 20); // Positioning each bar with spacing
//     rect.setAttribute("y", 400 - entry.times * 30); // The height of the bar is multiplied to scale it
//     rect.setAttribute("width", barWidth);
//     rect.setAttribute("height", entry.times * 30); // The height corresponds to the "times"
//     rect.setAttribute("fill", "#BDBDBD");

//     // Optionally add a label (user login)
//     var text = document.createElementNS("http://www.w3.org/2000/svg", "text");
//     text.setAttribute("x", (index * (barWidth + spacing)) + 20 + (barWidth / 2));
//     text.setAttribute("y", 400 - (entry.times * 30) - 5);
//     text.setAttribute("font-size", "12");
//     text.setAttribute("text-anchor", "middle");
//     text.textContent = entry.userlogin;

//     svg.appendChild(rect);
//     svg.appendChild(text);
//   });

//   // Append the SVG to a container
//   const graph1 = document.getElementById("graph1");
//   graph1.appendChild(svg);
// }















////////////////////////////////////////////
// i will use this query to get the data i need
// query {
//   user {
//       id
//       login
//       firstName
//       lastName
//       email
//       campus
//       auditRatio
//       totalUp
//       totalDown
//       xpTotal: transactions_aggregate(where: {type: {_eq: "xp"}, eventId: {_eq: 41}}) {
//         aggregate {
//           sum {
//             amount
//           }
//         }
//       }
//       events(where:{eventId:{_eq:56}}) {
//         level
//       }
//       xp: transactions(order_by: {createdAt: asc}
//         where: {type: {_eq: "xp"}, eventId: {_eq: 56}}) {
//           createdAt
//           amount
//           path
//       }
//       finished_projects: groups(where:{group:{status:{_eq:finished}}}) {
//           group {
//           path
//           status
//         }
//       }
//       current_projects: groups(where:{group:{status:{_eq:working}}}) {
//           group {
//           path
//           status
//           members {
//             userLogin
//           }
//         }
//       }
//       setup_project: groups(where:{group:{status:{_eq:setup}}}) {
//           group {
//           path
//           status
//           members {
//             userLogin
//           }
//         }
//       }
//       skills: transactions(
//           order_by: {type: asc, amount: desc}
//           distinct_on: [type]
//           where: {eventId: {_eq: 41}, _and: {type: {_like: "skill_%"}}}
//       ) {
//           type
//           amount
//       }
//   }
// }


















///////////////////
{/* <h2>Current Projects</h2>
    <div>
      ${userData.current_projects.length > 0 ?
    userData.current_projects.map(project => `
          <div>
            <strong>Project Path:</strong> ${project.group.path}
            <div><strong>Status:</strong> ${project.group.status}</div>
          </div>
        `).join('') :
    '<p>No current projects.</p>'
  }
    </div> */}



{/* <h2>Finished Projects</h2>
    <div>
      ${userData.finished_projects.length > 0 ?
    userData.finished_projects.map(project => `
          <div>
            <strong>Project Path:</strong> ${project.group.path}
            <div><strong>Status:</strong> ${project.group.status}</div>
          </div>
        `).join('') :
    '<p>No finished projects.</p>'
  }
    </div> */}































    /* /////////////////////////////////////////*/
  //   const query = `query {
  //     user {
  //       id
  //       login
  //       firstName
  //       lastName
  //       email
  //       campus
  //       auditRatio
  //       totalUp
  //       totalDown
  //       finished_projects: groups(
  //         where: {group: {status: {_eq: finished}, _and: [{path: {_like: "%module%"}}, {path: {_nilike: "%piscine-js%"}}]}}
  //       ) {
  //         group {
  //           path
  //           status
  //           members {
  //             userLogin
  //           }
  //         }
  //       }
  //       current_projects: groups(where: {group: {status: {_eq: working}}}) {
  //         group {
  //           path
  //           status
  //           members {
  //             userLogin
  //           }
  //         }
  //       }
  //     }
  //   }`;
  
  
  
  
  
  
  
  
  
  
  
  // Data.forEach(Element => {
  //       UserData.username = Element.login;
  //       UserData.firstName = Element.firstName;
  //       UserData.lastName = Element.lastName;
  //       UserData.email = Element.email;
  //       UserData.campus = Element.campus;
  //       UserData.auditRatio = (parseFloat(Element.auditRatio)).toFixed(1);
  //       UserData.totalUp = formatSize(parseFloat(Element.totalUp));
  //       UserData.totalDown = formatSize(parseFloat(Element.totalDown));
  //       UserData.successrojects = Element.finished_projects.length;
  //       finished_projects = Element.finished_projects;
  //     });
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  //   const profileHTML = (userData) => `
  //   <header class="header">
  //     <h1>User Profile</h1>
  //     <div id="user-data">
  //       <div><strong>Username:</strong> ${userData.username}</div>
  //       <div><strong>First Name:</strong> ${userData.firstName}</div>
  //       <div><strong>Last Name:</strong> ${userData.lastName}</div>
  //       <div><strong>Email:</strong> ${userData.email}</div>
  //       <div><strong>Campus:</strong> ${userData.campus}</div>
  //       <div><strong>Audit Ratio:</strong> ${userData.auditRatio}</div>
  //       <div><strong>Total Uploads:</strong> ${userData.totalUp}</div>
  //       <div><strong>Total Downloads:</strong> ${userData.totalDown}</div>
  //       <div><strong>Successful Projects:</strong> ${userData.successrojects}</div>
  //     </div>
  //   </header>
  
  //   <main class="main-content">
  //     <div id="profile-section">
  //       <h2>Current Projects</h2>
  //       <div>
  //         ${userData.current_projects.length > 0 ?
  //     userData.current_projects.map(project => `
  //             <div>
  //               <strong>Project Path:</strong> ${project.group.path}
  //               <div><strong>Status:</strong> ${project.group.status}</div>
  //             </div>
  //           `).join('') :
  //     '<p>No current projects.</p>'
  //   }
  //       </div>
        
  //       <h2>Finished Projects</h2>
  //       <div>
    //       ${userData.finished_projects.length > 0 ?
    //   userData.finished_projects.map(project => `
    //           <div>
    //             <strong>Project Path:</strong> ${project.group.path}
    //             <div><strong>Status:</strong> ${project.group.status}</div>
    //           </div>
    //         `).join('') :
    //   '<p>No finished projects.</p>'
    // }
  //       </div>
  //     </div>
  //   </main>
  
  //   <footer>
  //     <button id="logout">Logout</button>
  //   </footer>
  // `;
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  // First Name: ${userData.firstName}
  //       Last Name: ${userData.lastName}
  //       Email: ${userData.email}
  //       Audit Ratio: ${userData.auditRatio}
  //       Total Uploads: ${userData.totalUp}
  //       Total Downloads: ${userData.totalDown}
  //       Successful Projects: ${userData.successrojects}









//   `
// <header class="header">
//   Campus ${userData.campus}
//   <button id="logout">Logout</button>
// </header>
// <div class="main-content">
//     <div id="alldetails">
//       <details>
//       <summary><strong>Username:</strong> ${userData.username}</strong></summary>
//       <article>
//         <p>First Name: ${userData.firstName}</p>
//         <p>Last Name: ${userData.lastName}</p>
//         <p>Email: ${userData.email}</p>
//         <p>Audit Ratio: ${userData.auditRatio}</p>
//         <p>Total Uploads: ${userData.totalUp}</p>
//         <p>Total Downloads: ${userData.totalDown}</p>
//         <p>Successful Projects: ${userData.successrojects}</p>
//       </article>
//       </details>
//       <details>
//       <summary><strong>Successrojects:</strong> ${userData.successrojects}</strong></summary>
//         <article>
        // <p><strong>Projects Name</strong></p>
        // ${userData.finished_projects.map(project =>{
        //   const path = (project.group.path).split('/').pop();
        //   return `<p>${path}</p>`
        // }).join('')}
//         </article>
//       </details>
//     </div>
//     <div id="graphs">
//       <div id="graph1"></div>
//       <div id="graph2"></div>
//     </div>
// </div> 
// `